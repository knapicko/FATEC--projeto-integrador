import 'package:flutter/material.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

enum TipoContaCadastro { cliente, profissional }

class GoogleAuthService {
  static const webClientId =
      '558968043989-rmv282bv5r41ntrkk4bumu4v0m7hdbs7.apps.googleusercontent.com';

  static Future<User?> signInWithGoogle() async {
    final supabase = Supabase.instance.client;
    final googleSignIn = GoogleSignIn(clientId: webClientId);
    final googleUser = await googleSignIn.signIn();

    if (googleUser == null) return null;

    final googleAuth = await googleUser.authentication;
    final idToken = googleAuth.idToken;

    if (idToken == null) {
      throw Exception('Não foi possível obter o ID Token do Google.');
    }

    final response = await supabase.auth.signInWithIdToken(
      provider: OAuthProvider.google,
      idToken: idToken,
      accessToken: googleAuth.accessToken,
    );

    return response.user;
  }

  static Future<Map<String, dynamic>?> buscarPerfil(String authId) async {
    return Supabase.instance.client
        .from('usuarios')
        .select('tipo_conta')
        .eq('auth_id', authId)
        .maybeSingle();
  }

  static Future<bool> perfilExiste(String authId) async {
    final perfil = await buscarPerfil(authId);
    return perfil != null;
  }

  static String? extrairNome(User user) {
    final metadata = user.userMetadata;
    if (metadata != null) {
      final fullName = metadata['full_name'] ?? metadata['name'];
      if (fullName is String && fullName.isNotEmpty) return fullName;
    }
    return null;
  }
}
